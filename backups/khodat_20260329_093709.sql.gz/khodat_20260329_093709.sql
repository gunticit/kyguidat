-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: khodat
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `khodat`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `khodat` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `khodat`;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `articles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','published') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `author_id` bigint unsigned DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `articles_slug_unique` (`slug`),
  KEY `articles_author_id_foreign` (`author_id`),
  KEY `articles_status_index` (`status`),
  KEY `articles_published_at_index` (`published_at`),
  CONSTRAINT `articles_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES (1,'A b c','w','A b c','<p>A b c</p><ul><li class=\"ql-align-right\">123 h</li></ul><p>Bhhjjj</p>','https://storage.khodat.com/khodat/articles/20260329_161552_CWQmdjyc.webp','published',1,'2026-03-29 16:16:54','2026-03-29 16:15:57','2026-03-29 16:25:23');
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('khodat_cache_1b6453892473a467d07372d45eb05abc2031647a','i:1;',1774776838),('khodat_cache_1b6453892473a467d07372d45eb05abc2031647a:timer','i:1774776838;',1774776838),('khodat_cache_356a192b7913b04c54574d18c28d46e6395428ab','i:2;',1774776641),('khodat_cache_356a192b7913b04c54574d18c28d46e6395428ab:timer','i:1774776641;',1774776641),('khodat_cache_52f22fbd6e8eddbdf22c1976ae912a18c1d15880','i:1;',1774776672),('khodat_cache_52f22fbd6e8eddbdf22c1976ae912a18c1d15880:timer','i:1774776672;',1774776672),('khodat_cache_8860c9f1b32c91ad2482313af98f90a25629f0a7','i:1;',1774775827),('khodat_cache_8860c9f1b32c91ad2482313af98f90a25629f0a7:timer','i:1774775827;',1774775827),('khodat_cache_a0f9c9bbca12f3af20cebb46aa22a6d6c8a42335','i:1;',1774775305),('khodat_cache_a0f9c9bbca12f3af20cebb46aa22a6d6c8a42335:timer','i:1774775305;',1774775305);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consignment_histories`
--

DROP TABLE IF EXISTS `consignment_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consignment_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `consignment_id` bigint unsigned NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `changed_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `consignment_histories_changed_by_foreign` (`changed_by`),
  KEY `consignment_histories_consignment_id_index` (`consignment_id`),
  CONSTRAINT `consignment_histories_changed_by_foreign` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `consignment_histories_consignment_id_foreign` FOREIGN KEY (`consignment_id`) REFERENCES `consignments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consignment_histories`
--

LOCK TABLES `consignment_histories` WRITE;
/*!40000 ALTER TABLE `consignment_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `consignment_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consignments`
--

DROP TABLE IF EXISTS `consignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consignments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_number` int DEFAULT NULL,
  `notification_date` date DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_map_link` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(15,2) NOT NULL,
  `min_price` decimal(15,2) DEFAULT NULL,
  `seller_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `images` json DEFAULT NULL,
  `featured_image` longtext COLLATE utf8mb4_unicode_ci,
  `description_files` json DEFAULT NULL,
  `note_to_admin` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `internal_note` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `land_directions` json DEFAULT NULL,
  `land_types` json DEFAULT NULL,
  `road_display` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ward` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frontage_actual` decimal(10,2) DEFAULT NULL,
  `frontage_range` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area_range` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `has_house` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `residential_area` decimal(10,2) DEFAULT NULL,
  `residential_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `road` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area_dimensions` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `floor_area` decimal(10,2) DEFAULT NULL,
  `latitude` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consigner_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consigner_phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consigner_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sheet_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parcel_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` text COLLATE utf8mb4_unicode_ci,
  `seo_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_order` int NOT NULL DEFAULT '1',
  `status` enum('pending','approved','rejected','selling','sold','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `admin_note` text COLLATE utf8mb4_unicode_ci,
  `reject_reason` text COLLATE utf8mb4_unicode_ci,
  `approved_at` timestamp NULL DEFAULT NULL,
  `sold_at` timestamp NULL DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `auto_deactivated` tinyint(1) NOT NULL DEFAULT '0',
  `deactivated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `consignments_code_unique` (`code`),
  KEY `consignments_user_id_status_index` (`user_id`,`status`),
  KEY `consignments_code_index` (`code`),
  KEY `consignments_status_index` (`status`),
  KEY `consignments_province_index` (`province`),
  KEY `consignments_consigner_name_index` (`consigner_name`),
  KEY `consignments_created_at_index` (`created_at`),
  CONSTRAINT `consignments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consignments`
--

LOCK TABLES `consignments` WRITE;
/*!40000 ALTER TABLE `consignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `consignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipn_configurations`
--

DROP TABLE IF EXISTS `ipn_configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipn_configurations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ipn_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `merchant_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_config` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned DEFAULT NULL,
  `last_triggered_at` timestamp NULL DEFAULT NULL,
  `trigger_count` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ipn_configurations_created_by_foreign` (`created_by`),
  KEY `ipn_configurations_provider_is_active_index` (`provider`,`is_active`),
  CONSTRAINT `ipn_configurations_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipn_configurations`
--

LOCK TABLES `ipn_configurations` WRITE;
/*!40000 ALTER TABLE `ipn_configurations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipn_configurations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipn_logs`
--

DROP TABLE IF EXISTS `ipn_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ipn_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ipn_configuration_id` bigint unsigned DEFAULT NULL,
  `provider` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `response_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_data` json DEFAULT NULL,
  `response_data` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ipn_logs_ipn_configuration_id_foreign` (`ipn_configuration_id`),
  KEY `ipn_logs_provider_transaction_id_index` (`provider`,`transaction_id`),
  KEY `ipn_logs_created_at_index` (`created_at`),
  CONSTRAINT `ipn_logs_ipn_configuration_id_foreign` FOREIGN KEY (`ipn_configuration_id`) REFERENCES `ipn_configurations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipn_logs`
--

LOCK TABLES `ipn_logs` WRITE;
/*!40000 ALTER TABLE `ipn_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipn_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_wallets_table',1),(3,'0001_01_01_000002_create_consignments_table',1),(4,'0001_01_01_000003_create_payments_table',1),(5,'0001_01_01_000004_create_support_tickets_table',1),(6,'0001_01_01_000005_create_personal_access_tokens_table',1),(7,'0001_01_01_000006_create_posting_packages_table',1),(8,'2026_01_05_000001_update_consignments_for_land_selling',1),(9,'2026_01_16_000001_create_ipn_configurations_table',1),(10,'2026_02_08_000001_create_roles_permissions_tables',1),(11,'2026_02_09_000001_add_land_fields_to_consignments_table',1),(12,'2026_02_09_074102_change_featured_image_to_longtext_in_consignments_table',1),(13,'2026_02_09_144634_create_cache_table',1),(14,'2026_02_09_145659_add_free_posts_remaining_to_users_table',1),(15,'2026_02_09_145701_add_publishing_fields_to_consignments_table',1),(16,'2026_02_16_192000_add_purchase_type_to_wallet_transactions',1),(17,'2026_02_16_200000_create_articles_table',1),(18,'2026_02_16_210000_create_administrative_divisions_tables',1),(19,'2026_03_01_000001_add_indexes_to_consignments_table',1),(20,'2026_03_01_000002_add_featured_to_provinces_table',1),(21,'2026_03_01_000003_add_floor_area_to_consignments_table',1),(22,'2026_03_02_000001_add_residential_type_to_consignments_table',1),(23,'2026_03_02_000001_create_pages_table',1),(24,'2026_03_05_200000_alter_google_map_link_length',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('draft','published') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `display_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pages_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'Giới thiệu','gioi-thieu','<ul><li class=\"ql-align-right\">Giới thiệu đang cập nhật</li></ul>','published',0,'2026-03-29 16:16:28','2026-03-29 16:16:50');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `transaction_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` enum('vnpay','momo','bank_transfer') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `fee` decimal(15,2) NOT NULL DEFAULT '0.00',
  `net_amount` decimal(15,2) NOT NULL,
  `status` enum('pending','processing','completed','failed','cancelled','expired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `gateway_transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gateway_response` json DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `expired_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payments_transaction_id_unique` (`transaction_id`),
  KEY `payments_user_id_status_index` (`user_id`,`status`),
  KEY `payments_transaction_id_index` (`transaction_id`),
  KEY `payments_method_status_index` (`method`,`status`),
  CONSTRAINT `payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'users.view','Xem người dùng','users',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(2,'users.create','Tạo người dùng','users',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(3,'users.edit','Sửa người dùng','users',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(4,'users.delete','Xóa người dùng','users',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(5,'consignments.view','Xem bất động sản','consignments',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(6,'consignments.create','Tạo bất động sản','consignments',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(7,'consignments.edit','Sửa bất động sản','consignments',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(8,'consignments.delete','Xóa bất động sản','consignments',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(9,'consignments.approve','Duyệt bất động sản','consignments',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(10,'consignments.reject','Từ chối bất động sản','consignments',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(11,'payments.view','Xem thanh toán','payments',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(12,'payments.manage','Quản lý thanh toán','payments',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(13,'tickets.view','Xem hỗ trợ','tickets',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(14,'tickets.manage','Quản lý hỗ trợ','tickets',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(15,'settings.view','Xem cài đặt','settings',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(16,'settings.manage','Quản lý cài đặt','settings',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(17,'roles.view','Xem phân quyền','roles',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(18,'roles.manage','Quản lý phân quyền','roles',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (1,'App\\Models\\User',1,'auth_token','d09eface4c0ed197826b5b2ba6a8bc724a21535d5a8d2eb66a41178c4441eb1e','[\"*\"]','2026-03-29 16:02:04',NULL,'2026-03-29 16:01:21','2026-03-29 16:02:04'),(2,'App\\Models\\User',1,'auth_token','0114680e84ac81123bccdd439fcaf346a80057135bfa0889bf14d4e6d9fdaed8','[\"*\"]','2026-03-29 16:29:41',NULL,'2026-03-29 16:07:26','2026-03-29 16:29:41'),(3,'App\\Models\\User',1,'auth_token','e5e31acab77e0fe7235915be501ce8cf0e3960e72d255a1ca9c005f0b73bb312','[\"*\"]','2026-03-29 16:25:23',NULL,'2026-03-29 16:16:08','2026-03-29 16:25:23'),(4,'App\\Models\\User',4,'auth_token','f79f8ab4f87e12437da987f106f665367c2d0910068b58c885926832f030aa0f','[\"*\"]','2026-03-29 16:32:58',NULL,'2026-03-29 16:32:57','2026-03-29 16:32:58');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posting_packages`
--

DROP TABLE IF EXISTS `posting_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posting_packages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `duration_months` int NOT NULL,
  `price` decimal(12,0) NOT NULL,
  `original_price` decimal(12,0) DEFAULT NULL,
  `post_limit` int NOT NULL DEFAULT '-1',
  `featured_posts` int NOT NULL DEFAULT '0',
  `priority_support` tinyint(1) NOT NULL DEFAULT '0',
  `features` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_popular` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `posting_packages_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posting_packages`
--

LOCK TABLES `posting_packages` WRITE;
/*!40000 ALTER TABLE `posting_packages` DISABLE KEYS */;
INSERT INTO `posting_packages` VALUES (1,'Gói 1 tháng','1-month','Gói đăng bài 1 tháng, đăng tối đa 99 sản phẩm',1,100000,NULL,99,5,0,'[\"Đăng tối đa 99 sản phẩm\", \"Thời hạn 1 tháng\", \"Hỗ trợ qua email\", \"Thống kê cơ bản\"]',1,0,1,'2026-03-29 15:06:37','2026-03-29 16:29:41'),(2,'Gói 2 tháng','2-months','Gói đăng bài 2 tháng, đăng tối đa 99 sản phẩm',2,2500000,NULL,99,10,0,'[\"Đăng tối đa 99 sản phẩm\", \"Thời hạn 2 tháng\", \"Hỗ trợ qua email & chat\", \"Thống kê chi tiết\"]',1,1,2,'2026-03-29 15:06:37','2026-03-29 16:26:30'),(3,'Gói 3 tháng','3-months','Gói đăng bài 3 tháng phổ biến nhất, đăng tối đa 99 sản phẩm',3,3000000,NULL,99,15,1,'[\"Đăng tối đa 99 sản phẩm\", \"Thời hạn 3 tháng\", \"Hỗ trợ ưu tiên 24/7\", \"Thống kê nâng cao\", \"Đẩy bài lên top\"]',1,1,3,'2026-03-29 15:06:37','2026-03-29 16:26:18');
/*!40000 ALTER TABLE `posting_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provinces`
--

DROP TABLE IF EXISTS `provinces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provinces` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `images` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `provinces_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provinces`
--

LOCK TABLES `provinces` WRITE;
/*!40000 ALTER TABLE `provinces` DISABLE KEYS */;
INSERT INTO `provinces` VALUES (1,'TP Hồ Chí Minh','ho-chi-minh',1,1,0,NULL,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(2,'Đồng Nai','dong-nai',2,1,0,NULL,'2026-03-29 15:06:39','2026-03-29 15:06:39');
/*!40000 ALTER TABLE `provinces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permission`
--

DROP TABLE IF EXISTS `role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permission` (
  `role_id` bigint unsigned NOT NULL,
  `permission_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `role_permission_permission_id_foreign` (`permission_id`),
  CONSTRAINT `role_permission_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_permission_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permission`
--

LOCK TABLES `role_permission` WRITE;
/*!40000 ALTER TABLE `role_permission` DISABLE KEYS */;
INSERT INTO `role_permission` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(2,5),(3,5),(1,6),(3,6),(1,7),(3,7),(1,8),(1,9),(2,9),(1,10),(2,10),(1,11),(1,12),(1,13),(2,13),(1,14),(2,14),(1,15),(1,16),(1,17),(1,18);
/*!40000 ALTER TABLE `role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','Quản trị viên','Toàn quyền hệ thống','2026-03-29 15:06:36','2026-03-29 15:06:36'),(2,'moderator','Kiểm duyệt','Duyệt và quản lý nội dung','2026-03-29 15:06:36','2026-03-29 15:06:36'),(3,'publisher','Đăng bài','Tạo và quản lý bài đăng','2026-03-29 15:06:36','2026-03-29 15:06:36');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('0MAv80XPZoG0fMnQwkNVspJuW2e5fYtL3hFxiueQ',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiaW5veVBDak1yYXVjOVNWR0k0OUFwT21CNjBhc0ZPTkxhQ1dYVXBYbiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTc6Imh0dHA6Ly9raG9kYXQuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774769746),('11X7pgj3buF9Ht12toGwy6V6BHysV20ZJTcFW8gZ',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36; compatible; OAI-SearchBot/1.3; +https://openai.com/searchbot','YTozOntzOjY6Il90b2tlbiI7czo0MDoicW4yWE1yWXlzUUliMUlsN1V2SlVyMW5RZmQ3V2I2R0d1UXo4Y3Y5MSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6ODM6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1kYXQtcGh1b25nLXR1YW4teHVhbi10aGFuaC1waG8tZG9uZy14b2FpLXRpbmgtYmluaC1waHVvYy0xNTI1Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774771445),('1okelW4Fq5u7la8YEQp54LKvneR7nkmkjfmzTcys',NULL,'172.17.0.1','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiczl1eG9Rd2pvcmhkVDFjMndET1ZIMGxESnFXT2JxeDhEMVdQUm43ZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHA6Ly9raG9kYXQuY29tL3JvYm90cy50eHQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1774769344),('2nNSlEb8KDCEpJLylJncd84TgSvdaC4FLirwihvL',NULL,'172.17.0.1','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUVVJd3NwMzRyVHE1QTd6MW5YU3kyRGxWcTJUNTV4OVlOcWdMVHhEWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDY6Imh0dHA6Ly93d3cua2hvZGF0LmNvbS8ud2VsbC1rbm93bi9zZWN1cml0eS50eHQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1774769457),('61cGYcZR1jkukdo3pNSRD1YGekNii8fLgUkkrCDK',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoibDJmeTlYZ3pRbkdZVWtyRlBPSDRabDBYdlltVDB2REh1UTZiRWRWUSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly9raG9kYXQuY29tL2FwaS9zZXR0aW5ncyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774775321),('82q2b8zi0oRGYOYNuSAKne7vGnDJOLFuEmJQ6fgL',NULL,'172.17.0.1','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiaGFIeWdSR3ZXc2VzaFR0MjRqY3VSMW1IcVNqRExNWmloUlE4bnY2cyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NzM6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1kYXQteGEtdGFuLWh1bmctaHV5ZW4tZG9uZy1waHUtdGluaC1iaW5oLXBodW9jLTEyNTgiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1774776961),('8A9K2ArUdSXmdH4STWZujVibUcdYsZOhqiZDN4Ul',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.153 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','YTozOntzOjY6Il90b2tlbiI7czo0MDoicWNSUTZLMGU5VUI0MzlwQXhDdU5JWDRlTzBQV1ZPUFhBZlRLeFlTNiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjY6Imh0dHA6Ly93d3cua2hvZGF0LmNvbS9iYW4tZGF0LXBodW9uZy1iaW5oLXBodW9jLXRpbmgtZG9uZy1uYWktMTE3MCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774774072),('9OiT2qVOG3dba1Oe5GLixvOs6YNm9v3n34IPj3Av',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiMnlGamhSTE9kdDJ5bUFhaDNMN1R2QkF1TW5NbFQxbDU0RW1nUWxRNCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly9raG9kYXQuY29tL2FwaS9zZXR0aW5ncyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774775617),('9y4LoHDmiHyZ5QWr5e7t2xjuGz08wmByktVtMXHe',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36; compatible; OAI-SearchBot/1.3; robots.txt; +https://openai.com/searchbot','YTozOntzOjY6Il90b2tlbiI7czo0MDoicmFiQTRGNWxGaUdlWktwSEUxc2xqcG9qS2phUWp0dWxJQjFJUnpMVyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHA6Ly9raG9kYXQuY29tL3JvYm90cy50eHQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1774769951),('a47JM7CJhKD8kYDcUTnfXltaE7TPFoygbCtjS4u2',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiaDNmbVRmWHQ2VVlZdzVUSWU2TkZWQ2dOT0VxUWE3V2N6REl1RDg0VSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly9raG9kYXQuY29tL2FwaS9zZXR0aW5ncyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774769761),('ABe33Eue72fAt3OX3z6HeXqY2LriM626LfhhvFis',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36; compatible; OAI-SearchBot/1.3; +https://openai.com/searchbot','YTozOntzOjY6Il90b2tlbiI7czo0MDoiN3FEbTZKS0U0dWg5ZkJhQnhLb0JrN09FSjJPWU1haERxTzhaaTlmbiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NzM6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1kYXQteGEtdGFuLWxvaS1odXllbi1kb25nLXBodS10aW5oLWJpbmgtcGh1b2MtLTE2MDAiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1774769957),('BJpOp9XPhT2mT7YgqONriRzvPHAb96UzE8qxX37i',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiR0JHaDVXMUpyM2RENGVIbEJSdWxON0s3SUZsUEdnaWpKaFMzYXZLTCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly9raG9kYXQuY29tL3Rpbi10dWMvdyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774776325),('bUFn2QBKzT8poPuYZsdlB8I1Eoo0Z797Ihuk3fUZ',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36; compatible; OAI-SearchBot/1.3; +https://openai.com/searchbot','YTozOntzOjY6Il90b2tlbiI7czo0MDoiN0xRMWhNSTJTeDNDb3ZJcHkzUTBiaVp3NGtXZHNmNTZwRDI5WjlMOSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NzQ6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1kYXQteGEtcGh1LXRydW5nLWh1eWVuLWRvbmctcGh1LXRpbmgtYmluaC1waHVvYy0xNDUxIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774771433),('CZOGeu29iHE4jQn7Qss8te1Aw4LqudCGfcMFFHci',NULL,'172.17.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoieFNKVTgzeWhKZ2dJR0pESEpKemZqVTdqWU40T1BGTzNWa1oxWjQ4UCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjI6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1uaGEtcGh1b25nLXRhbi1hbi10aGFuaC1waG8tY2FuLXRoby0xMjM5Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774774259),('D5Kyv28tRI7JT2GV6ymh1FApRyVmx04PZmqdWcwa',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.153 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSnZYdXJ5andNeVhyOTROUlBBSmt5U1pYUXYwQ0JJRWpKZWlZaDRnaSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjA6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1uaGEtcGh1b25nLXRhbi1uaW5oLXRpbmgtdGF5LW5pbmgtMTI2NSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774773254),('EZ6ck69jwq7Nbrp9HSpsFUmFHLMkwFYqKUuLbfpk',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoieHhqV3JtTFAydkVMMVVEbU8wcUQzOXh2dTdlcDJVSDVSZEZQQm5IdSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly93d3cua2hvZGF0LmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774775433),('g1PrIzHU3v3uKKY1CwkJqqTddkCc3BkQhURzVKlN',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36; compatible; OAI-SearchBot/1.3; +https://openai.com/searchbot','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQmJtdVJYMDkyZnlHQTNUT3F3dXdEaVFVUHh4NGxvRldDdTJUdG4wUCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NzE6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1kYXQteGEtbmhhLWJpY2gtdGhpLXhhLWNob24tdGhhbmgtdGluaC1iaW5oLXBodW9jIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774769375),('gY0Xqy7vubz6tf0NgiVvWQWWwAFhmLw5HiQ5ZLf9',NULL,'172.17.0.1','','YTozOntzOjY6Il90b2tlbiI7czo0MDoibkNpR3BqanVVODZLOHhKYlZFUzJ3SWt5M2lmV2tIR0dIQ05xTVM0UyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly9raG9kYXQuY29tL2lveGkwMDIuUGhQNyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774770836),('gzPBsukOthqikXmJ1ongbA7tEmPbeydCPX9BUqLZ',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.153 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiamRESDN3QWhsWDRkNERWU0NrTVUzNDJhdHZVSWxua2tTMHFmWGlDWSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9raG9kYXQuY29tL2JhdC1kb25nLXNhbi81MSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774768723),('H9tqPzYosbREjFc91fGXlTkJt37VWuAFZ6Rha8Tt',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36; compatible; OAI-SearchBot/1.3; +https://openai.com/searchbot','YTozOntzOjY6Il90b2tlbiI7czo0MDoiRURyNm1CempLSVAxbldWblNGVXhjTzdJT2ZLa1NjWE9lYUo4Ukh5WSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NzI6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1kYXQteGEtdGhhbmgtaG9hLWh1eWVuLWJ1LWRvcC10aW5oLWJpbmgtcGh1b2MtMTI1NiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774771443),('IgSY5eyAHXnZLibkBDg4sQ7v6JU6yUNPkDHymzfJ',NULL,'172.17.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoicDBlcjgwbjdzakZzZnc3TVdZamJiQllOaHZYeWVWeFlkWFc2NzdzVSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTc6Imh0dHA6Ly9raG9kYXQuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774769830),('iOxWazjbxHe6xkAJAdXBTRctZmcGsJQD51Czt9oK',NULL,'172.17.0.1','Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.815.0 Safari/535.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoid2MwVkY5b3dJM2tIUHVia096Z1VTNlRJbFhoSnhMZk1hWjJZZ3Y2eCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTg6Imh0dHA6Ly9raG9kYXQuY29tL3N5c3RlbS9zdG9yYWdlL2xvZ3MvZmlyc3RkYXRhX3JlbW90ZS5sb2ciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1774776897),('j5rn7zZutWdY9gLVLyL3SjJDjjb76fDuKwreJqiF',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36; compatible; OAI-SearchBot/1.3; +https://openai.com/searchbot','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYTJtQU1maTh6dGFPU3lQSmhmU0pOT1dlTnI0RkFUckxOZHZQRllOSSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NzU6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1kYXQteGEtdGFuLXBodW9jLWh1eWVuLWRvbmctcGh1LXRpbmgtYmluaC1waHVvYy0tMTc5NiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774769438),('J8b7oe5iC8FW3FEKbEBmQfImAAGuYsjL5lRMQRjv',NULL,'172.17.0.1','Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiV3NoakNkemJEcXVCTDVIRmZzb0RQM0ViRUdWVmdKb3V0WU1BaFBvYSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHA6Ly9raG9kYXQuY29tL3JvYm90cy50eHQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1774770991),('kU130YDLZsOfXBoz311Rqe27Njkqt3av0RD1nhP0',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiV3VuYU5xRWlEUjloZWJDdkVISWZhU3FidjJyd1JpVVptYXAyMFFvQiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjI6Imh0dHA6Ly9raG9kYXQuY29tL2FwaS9jb25zaWdubWVudHM/bGltaXQ9MzAmcGFnZT0xJnNvcnQ9bGF0ZXN0Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774776505),('KWGIDCBbVsLeXZoSEwe80DxwWMugkPDanj6nKmr5',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWXkxajY0Y0JNVVBFeUdDREdWM2JjemNYbG50M1VMeUJzWHZKS1VhaiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly9raG9kYXQuY29tL2FwaS9zZXR0aW5ncyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774771732),('Kx7HWCFwdmdEWYYQzZ9jHlNN0BAiOU435jYrew4t',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.153 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZzNQeWl2VktrWUsydzBxV1kzQkZtWWZVa0sxYmJFR3JoQ09peDZzbCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTc6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1kYXQteGEtbmluaC1kaWVuLXRpbmgtdGF5LW5pbmgtMTIzNCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774774890),('l2PBta3iPmGdyfWboWHzkKFVTKt9tjnH2sfFTVDt',NULL,'172.17.0.1','Mozilla/5.0 (compatible; Googlebot/2.1 +http://www.googlebot.com/bot.html)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVkttbmRKRmtLZzc1QXJpWXFJdnAzQ1E5ZldFb1pQeDNibUZCU0R4ZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjA6Imh0dHA6Ly9raG9kYXQuY29tL3N5c3RlbS9zdG9yYWdlL2xvZ3MvbWVyY2hhbnRfb25lX2RlYnVnLnR4dCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774773678),('LCC8yajhF3opaYmCjlZ5V2ZlCm5KRMf3o9w4LLMu',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.153 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','YTozOntzOjY6Il90b2tlbiI7czo0MDoicldONWRvNVF6TFhtNHNqUUJOVmNWT0c0WThnTmpBb09RVUc5RXFNbCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjA6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1kYXQtcGh1b25nLWJpZW4taG9hLXRpbmgtZG9uZy1uYWktMTExNCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774768844),('lZpZRPfMyy1ipaRvG3pK2EV6eoCP45pIj4JMB6b1',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36','YToyOntzOjY6Il90b2tlbiI7czo0MDoiRDlxYVNsY1JKYWpYdUp0OGtwamtXa1ZNNEdUN2ZvcHdDMmZVT0o5VSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774775336),('O3uxYZ0PVzdX0L7k2SNpfJKs2FcjOn2NkYrY1Z27',NULL,'172.17.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/146.0.7680.151 Mobile/15E148 Safari/604.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNXFycUY5UkZLSFZoSWg0Yk5tUmFyWnRwNkxsdEpLTmladkwwRjRoYiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTc6Imh0dHA6Ly9raG9kYXQuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774769842),('O5TfxCY20NiesigCDZUn5ljecQNq1uM9V27RbKWi',NULL,'172.17.0.1','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVThIVFlnQVEzUUtEMjBvU1RlWTlZYlQ5TndPVDNKSlRSWGJWNjVWYiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NzM6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1kYXQteGEtbWluaC1odW5nLWh1eWVuLWJ1LWRhbmctdGluaC1iaW5oLXBodW9jLTEwMDciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1774769346),('oYgSVNxphDwbtxQbHOKVg4DX5sitv0gEyX6XOWUD',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.153 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSFhETzdIY2JEYVB1RFpWUEY5ZE5DVTU3THNCQ0lpUTNkMnZaZEVMZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjE6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1kYXQtcGh1b25nLXRyYW4tYmllbi10aW5oLWRvbmctbmFpLTEwOTUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1774770821),('OZNtWVH37JNZGPXhGNvWY7VvghUQZQrWPVFegIRv',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36; compatible; OAI-SearchBot/1.3; robots.txt; +https://openai.com/searchbot','YTozOntzOjY6Il90b2tlbiI7czo0MDoib2twUGhySHNwdTJQN3hubVpXZm52VEFjbkVRcTJkZm1lTUVxYTRQciI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHA6Ly9raG9kYXQuY29tL3JvYm90cy50eHQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1774771422),('pSfjboWYDiqkVdxZ0yuk0fwnym5BoAMIFxw6nvsM',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.153 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ3ZFV3BSOUJsaDc3UEVzWDlYVHZrY1J1TUdSaXFveWcyWTFjbmtkNCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjI6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1uaGEtcGh1b25nLWJpbmgtcGh1b2MtdGluaC1kb25nLW5haS0xMDY5Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774770940),('QbGA6xw7uDRQHUXiWIMojRcbwYCsWSG7l5nnGih5',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.153 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiT0hrWTM1cHc2dDY2WDVSbVpHZ1h5S2hBR0VZQTV5dE1VZTNUYmN1ViI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NzQ6Imh0dHA6Ly9raG9kYXQuY29tL2luZGV4LnBocD9jb3VudHJ5X2lkPSZwYWdlX251bWJlcj0yMyZyb3V0ZT1jb21tb24lMkZob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774771618),('QOWt5awq7qbHi7eqLdksQV2ZMZoku3R5U3ow1S1b',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36; compatible; OAI-SearchBot/1.3; robots.txt; +https://openai.com/searchbot','YTozOntzOjY6Il90b2tlbiI7czo0MDoielRpYzdCMFRLMzUwdzBOMllua2hCQ1VoOGFmT3lyalo5NHYyeUtjYSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHA6Ly9raG9kYXQuY29tL3JvYm90cy50eHQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1774773016),('r3xaDG9uZGPqOuDqqJ8WomjTGcISmyDQXxW76Mrq',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.153 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','YTozOntzOjY6Il90b2tlbiI7czo0MDoieTFmSlhxcEdRTlNqRXdnZ2JqTXJ4RkpGZ3ZjdU5id05pN1BhS01COCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTY6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1kYXQtcGh1b25nLWRvbmcteG9haS1kb25nLW5haS0xMDM2Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774768845),('RiPPxQhux3Eseq3RCBM2LneSZR8YwwVao5XltuVW',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 8.0; Pixel 2 Build/OPD3.170816.012) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.7452.1469 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUHdVUkJjN0JhbTVubkRLckx1cWhkWXprUnU1T0VQNU5wTnB1ZHI0TCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9raG9kYXQuY29tL2JhdC1kb25nLXNhbi82MiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774770495),('RqRUqfdXo6PWq46IUbKKim68nQCnlB3laxNSa9hi',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.153 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiMUNEc0c2aUxuVzAzRURYY1JteUtVQUhieFFFSUU3ZFdyQ21CMWIxeCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjI6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1kYXQtcGh1b25nLWJpbmgtcGh1b2MtdGluaC1kb25nLW5haS0xMTM3Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774772436),('ScBeUAnefOfVyAM1RYBFbHM5xFniy3SP4cWfaLnf',NULL,'172.17.0.1','Mozilla/5.0 (compatible; DotBot/1.2; +https://opensiteexplorer.org/dotbot; help@moz.com)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ3FMbnZMNTA5blNoMjhqeVRTa2NlUGZXZVY3YjQ0d3lRRFl6QmNqSiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjI6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1uaGEtcGh1b25nLWJpbmgtcGh1b2MtdGluaC1kb25nLW5haS0xMTYyIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774773918),('tdJBZOWxRyNjq8W2G3tstRx0340jtHiXGV3e8TTI',NULL,'172.17.0.1','Mozilla/5.0 (compatible; DotBot/1.2; +https://opensiteexplorer.org/dotbot; help@moz.com)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiaUJzU2NXSkVmMDhHSm5ob2VxYVFtU3ZlSnVKb1dxMnh0M2l2V1ZMbyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHA6Ly9raG9kYXQuY29tL3JvYm90cy50eHQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1774773256),('tRk7f1nfGcQNQ5PoROGXJfn0IBZWeW3CzGR35i3u',NULL,'172.17.0.1','Chrome Privacy Preserving Prefetch Proxy','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYTZnNHplTmx4WTk5aHlWZHJLWXZUWWdzR24yRVNheGl4M255YmJnMiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDQ6Imh0dHA6Ly9raG9kYXQuY29tLy53ZWxsLWtub3duL3RyYWZmaWMtYWR2aWNlIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774774259),('tt7DMSZSI0HoYCb0XzE9HMwLzXs58IFDnLnBcmZL',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.153 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNm9HRnhObmJvRWRKNXVOb2NaOGp3cEpmSHV2ejQ2UjJIQVpyVjhyMCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjU6Imh0dHA6Ly93d3cua2hvZGF0LmNvbS9iYW4tZGF0LXBodW9uZy10cmFuZy1kYWktdGluaC1kb25nLW5haS0xMTAyIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774769800),('TzCMwhjsIrljY2K4JbRofPFQ7u4vArV8FwoFBpte',NULL,'172.17.0.1','Python/3.9 aiohttp/3.13.3','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVW14T09wMkNwSEpNOUVZRXkxY0xhNWVMZ1pUUTdmTXc5RnJWam1HYiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTc6Imh0dHA6Ly9raG9kYXQuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774770907),('UCqSoEqL4rgZ3E4kg76yTaOpngA4HmAQllNQhirD',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiU3hBWXB3QkI5ZmdYVmE3c3p2UDJmTW1BSHpPdGYyQk5zM2VIRE5iSCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjI6Imh0dHA6Ly9raG9kYXQuY29tL2FwaS9jb25zaWdubWVudHM/bGltaXQ9MzAmcGFnZT0xJnNvcnQ9bGF0ZXN0Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774774931),('uFKMXA6Gb8g0jzIXl7ekQPbvznCQSv4x3GFG6Ewg',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoienNCaTBld05MOUk4UTFYOXo1cnFpbWM1WVZWcXdLc3JmckFRQmcwcCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTc6Imh0dHA6Ly9raG9kYXQuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774777026),('Va3yUYLrMdjc4uxOvoetKtPrDFQ3jTcw7nLw2zaJ',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoialNMWHVieXhnazA0S2JyZlVUOTBrUmd4a0hDMEFVamIxUlVNUjVUbiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly9raG9kYXQuY29tL2Zhdmljb24uaWNvIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774776467),('vgOVjNUlsbFMbMsQSjFmb0Tkjy7GVWJatS3fpudp',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','YToyOntzOjY6Il90b2tlbiI7czo0MDoiZjEyT0xCUk96SUlFUDNGenNJSk55RzFzcmpyOEJwVnlhT000a0J4WSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774771725),('wMOoaoVclDdQRr6V6U2PKeLWzQCtQh4IGonOVDfd',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.153 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVUhLdGRzOWpLcGFSV216WWVBeGxwY3dOQVNBbjlmZ1lnZk5weUNkZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjY6Imh0dHA6Ly93d3cua2hvZGF0LmNvbS9iYW4tZGF0LXBodW9uZy1iaW5oLXBodW9jLXRpbmgtZG9uZy1uYWktMTE3NiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774773825),('wUxSOby2fEzR01Cmjs2pJn1DGvbXSonoyghzZBLU',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36; compatible; OAI-SearchBot/1.3; +https://openai.com/searchbot','YTozOntzOjY6Il90b2tlbiI7czo0MDoidFRBV2d1c1p0d2pNU3hVMGFFR1RZazBzYThOOG1jWXh0YzdpNEh3UyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NzY6Imh0dHA6Ly9raG9kYXQuY29tL2Jhbi1kYXQteGEtbmhhLWJpY2gtdGhpLXhhLWNob24tdGhhbmgtdGluaC1iaW5oLXBodW9jLTEyNDUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1774771436),('x1lsJnPe5QfjoBkgtFBCImby42jfq9ETXYuW1xH9',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.153 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiV2NpOWRJRnBmbE5zeGE4QjYzMjFFYVBjUWxURHdXRXowTUFxa2FnRCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjY6Imh0dHA6Ly93d3cua2hvZGF0LmNvbS9iYW4tZGF0LXBodW9uZy1iaW5oLXBodW9jLXRpbmgtZG9uZy1uYWktMTE0NSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1774776527),('yM59vbHAzX67sNmqrW7zo2BZf0TXggufiuecRyj5',NULL,'172.17.0.1','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.7680.153 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVUhEMms4Z3FSSUYycG4yWVBmb2cySG1BV3pRQkFFQXlScUxKazB1ZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjI6Imh0dHA6Ly93d3cua2hvZGF0LmNvbS9iYW4tZGF0LXBodW9uZy1hbi1sb2MtdGluaC1kb25nLW5haS0xMTYzIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1774775709),('Z2UzBmpaaK1mzMpIaCa7EJEAhWWsiqFfnyKjYkdp',NULL,'172.17.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36; compatible; OAI-SearchBot/1.3; robots.txt; +https://openai.com/searchbot','YTozOntzOjY6Il90b2tlbiI7czo0MDoiTXVKR0FGWmp0azBLUUlQbXQ0ejV4aVJTTWM3bXNPdWRXZHRvZE9pWSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHA6Ly9raG9kYXQuY29tL3JvYm90cy50eHQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1774769375),('z9hmtBaaOVwpjAgaBph2AA5Ufpqso01Y1zZHvFpB',NULL,'172.17.0.1','Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiRlJvR05kdDRnaEt0eDYxdFJuMGdncFFzU2owbjgzZlFvQWJVRkFpVyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHA6Ly9raG9kYXQuY29tL3JvYm90cy50eHQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1774776958);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_messages`
--

DROP TABLE IF EXISTS `support_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `support_ticket_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachments` json DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `support_messages_user_id_foreign` (`user_id`),
  KEY `support_messages_support_ticket_id_index` (`support_ticket_id`),
  CONSTRAINT `support_messages_support_ticket_id_foreign` FOREIGN KEY (`support_ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `support_messages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_messages`
--

LOCK TABLES `support_messages` WRITE;
/*!40000 ALTER TABLE `support_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_tickets`
--

DROP TABLE IF EXISTS `support_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_tickets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `ticket_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` enum('general','payment','consignment','account','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'general',
  `priority` enum('low','medium','high','urgent') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'medium',
  `status` enum('open','in_progress','waiting_reply','resolved','closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `assigned_to` bigint unsigned DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `support_tickets_ticket_number_unique` (`ticket_number`),
  KEY `support_tickets_assigned_to_foreign` (`assigned_to`),
  KEY `support_tickets_user_id_status_index` (`user_id`,`status`),
  KEY `support_tickets_ticket_number_index` (`ticket_number`),
  CONSTRAINT `support_tickets_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `support_tickets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_tickets`
--

LOCK TABLES `support_tickets` WRITE;
/*!40000 ALTER TABLE `support_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_packages`
--

DROP TABLE IF EXISTS `user_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_packages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `posting_package_id` bigint unsigned NOT NULL,
  `amount_paid` decimal(12,0) NOT NULL,
  `started_at` timestamp NOT NULL,
  `expires_at` timestamp NOT NULL,
  `posts_used` int NOT NULL DEFAULT '0',
  `featured_posts_used` int NOT NULL DEFAULT '0',
  `status` enum('active','expired','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `payment_status` enum('pending','paid','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_packages_posting_package_id_foreign` (`posting_package_id`),
  KEY `user_packages_user_id_status_index` (`user_id`,`status`),
  KEY `user_packages_expires_at_status_index` (`expires_at`,`status`),
  CONSTRAINT `user_packages_posting_package_id_foreign` FOREIGN KEY (`posting_package_id`) REFERENCES `posting_packages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_packages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_packages`
--

LOCK TABLES `user_packages` WRITE;
/*!40000 ALTER TABLE `user_packages` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_role` (
  `user_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `user_role_role_id_foreign` (`role_id`),
  CONSTRAINT `user_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_role_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` VALUES (1,1,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(2,2,'2026-03-29 15:06:37','2026-03-29 15:06:37'),(3,3,'2026-03-29 15:06:37','2026-03-29 15:06:37');
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `free_posts_remaining` int NOT NULL DEFAULT '3',
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive','banned') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_provider_provider_id_index` (`provider`,`provider_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Administrator','admin@khodat.com','2026-03-29 15:06:36','$2y$12$tcpVcmh5vB1fJeQgrY3s8O7Ibl5st8s3lHnzshiCZIZM8mq50PBvm',NULL,3,NULL,NULL,NULL,'active',NULL,'2026-03-29 15:06:36','2026-03-29 15:06:36'),(2,'Kiểm Duyệt Viên','moderator@khodat.com','2026-03-29 15:06:37','$2y$12$JP/CoqHt4CmPlWsQ25BPieMHZg5vmbx/wMajqT3hGIQa7ew1hZioG',NULL,3,NULL,NULL,NULL,'active',NULL,'2026-03-29 15:06:37','2026-03-29 15:06:37'),(3,'Người Đăng Bài','publisher@khodat.com','2026-03-29 15:06:37','$2y$12$d7g2Jwq7T262kSOEEMKg2uqbWw/yg/d3I42dayUildVoicqK4S56G',NULL,3,NULL,NULL,NULL,'active',NULL,'2026-03-29 15:06:37','2026-03-29 15:06:37'),(4,'Doan Hung','hocvalam.mmo@gmail.com','2026-03-29 16:32:57',NULL,NULL,3,'https://lh3.googleusercontent.com/a/ACg8ocLgYkKm-vkZd9FpkoGLO8bBylgsYBoBj-WhyPkf5EncrxwKa0k=s96-c','google','112673299702546601131','active',NULL,'2026-03-29 16:32:57','2026-03-29 16:32:57');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wallet_transactions`
--

DROP TABLE IF EXISTS `wallet_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wallet_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `wallet_id` bigint unsigned NOT NULL,
  `type` enum('deposit','withdraw','consignment','refund','purchase') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `balance_before` decimal(15,2) NOT NULL,
  `balance_after` decimal(15,2) NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wallet_transactions_wallet_id_created_at_index` (`wallet_id`,`created_at`),
  KEY `wallet_transactions_reference_type_reference_id_index` (`reference_type`,`reference_id`),
  CONSTRAINT `wallet_transactions_wallet_id_foreign` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallet_transactions`
--

LOCK TABLES `wallet_transactions` WRITE;
/*!40000 ALTER TABLE `wallet_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `wallet_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wallets`
--

DROP TABLE IF EXISTS `wallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wallets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `balance` decimal(15,2) NOT NULL DEFAULT '0.00',
  `frozen_balance` decimal(15,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wallets_user_id_unique` (`user_id`),
  CONSTRAINT `wallets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallets`
--

LOCK TABLES `wallets` WRITE;
/*!40000 ALTER TABLE `wallets` DISABLE KEYS */;
INSERT INTO `wallets` VALUES (1,4,0.00,0.00,'2026-03-29 16:32:57','2026-03-29 16:32:57');
/*!40000 ALTER TABLE `wallets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wards`
--

DROP TABLE IF EXISTS `wards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wards` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `province_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('phuong','xa','dac_khu') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'phuong',
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wards_province_id_slug_unique` (`province_id`,`slug`),
  CONSTRAINT `wards_province_id_foreign` FOREIGN KEY (`province_id`) REFERENCES `provinces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=239 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wards`
--

LOCK TABLES `wards` WRITE;
/*!40000 ALTER TABLE `wards` DISABLE KEYS */;
INSERT INTO `wards` VALUES (1,1,'P. Sài Gòn','phuong','p-sai-gon',1,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(2,1,'P. Tân Định','phuong','p-tan-dinh',2,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(3,1,'P. Bến Thành','phuong','p-ben-thanh',3,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(4,1,'P. Cầu Ông Lãnh','phuong','p-cau-ong-lanh',4,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(5,1,'P. Bàn Cờ','phuong','p-ban-co',5,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(6,1,'P. Xuân Hòa','phuong','p-xuan-hoa',6,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(7,1,'P. Nhiêu Lộc','phuong','p-nhieu-loc',7,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(8,1,'P. Vĩnh Hội','phuong','p-vinh-hoi',8,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(9,1,'P. Khánh Hội','phuong','p-khanh-hoi',9,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(10,1,'P. Xóm Chiếu','phuong','p-xom-chieu',10,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(11,1,'P. Chợ Quán','phuong','p-cho-quan',11,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(12,1,'P. An Đông','phuong','p-an-dong',12,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(13,1,'P. Chợ Lớn','phuong','p-cho-lon',13,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(14,1,'P. Bình Tiên','phuong','p-binh-tien',14,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(15,1,'P. Bình Tây','phuong','p-binh-tay',15,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(16,1,'P. Bình Phú','phuong','p-binh-phu',16,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(17,1,'P. Phú Lâm','phuong','p-phu-lam',17,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(18,1,'P. Tân Hưng','phuong','p-tan-hung',18,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(19,1,'P. Tân Thuận','phuong','p-tan-thuan',19,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(20,1,'P. Tân Mỹ','phuong','p-tan-my',20,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(21,1,'P. Phú Thuận','phuong','p-phu-thuan',21,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(22,1,'P. Chánh Hưng','phuong','p-chanh-hung',22,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(23,1,'P. Bình Đông','phuong','p-binh-dong',23,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(24,1,'P. Phú Định','phuong','p-phu-dinh',24,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(25,1,'P. Vườn Lài','phuong','p-vuon-lai',25,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(26,1,'P. Diên Hồng','phuong','p-dien-hong',26,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(27,1,'P. Hòa Hưng','phuong','p-hoa-hung',27,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(28,1,'P. Bình Thới','phuong','p-binh-thoi',28,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(29,1,'P. Phú Thọ','phuong','p-phu-tho',29,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(30,1,'P. Hòa Bình','phuong','p-hoa-binh',30,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(31,1,'P. Minh Phụng','phuong','p-minh-phung',31,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(32,1,'P. Đông Hưng Thuận','phuong','p-dong-hung-thuan',32,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(33,1,'P. Trung Mỹ Tây','phuong','p-trung-my-tay',33,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(34,1,'P. Tân Thới Hiệp','phuong','p-tan-thoi-hiep',34,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(35,1,'P. Thới An','phuong','p-thoi-an',35,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(36,1,'P. An Phú Đông','phuong','p-an-phu-dong',36,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(37,1,'P. Bình Trị Đông','phuong','p-binh-tri-dong',37,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(38,1,'P. Tân Tạo','phuong','p-tan-tao',38,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(39,1,'P. An Lạc','phuong','p-an-lac',39,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(40,1,'P. Bình Hưng Hòa','phuong','p-binh-hung-hoa',40,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(41,1,'P. Tên Lửa','phuong','p-ten-lua',41,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(42,1,'P. Bình Quới','phuong','p-binh-quoi',42,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(43,1,'P. Bạch Đằng','phuong','p-bach-dang',43,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(44,1,'P. Hàng Xanh','phuong','p-hang-xanh',44,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(45,1,'P. Thanh Đa','phuong','p-thanh-da',45,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(46,1,'P. Quang Trung','phuong','p-quang-trung',46,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(47,1,'P. Hạnh Thông Tây','phuong','p-hanh-thong-tay',47,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(48,1,'P. An Hội','phuong','p-an-hoi',48,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(49,1,'P. Thống Nhất','phuong','p-thong-nhat',49,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(50,1,'P. Phú Nhuận','phuong','p-phu-nhuan',50,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(51,1,'P. Phan Xích Long','phuong','p-phan-xich-long',51,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(52,1,'P. Tân Sơn Nhất','phuong','p-tan-son-nhat',52,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(53,1,'P. Tân Bình','phuong','p-tan-binh',53,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(54,1,'P. Gia Định','phuong','p-gia-dinh',54,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(55,1,'P. Bảy Hiền','phuong','p-bay-hien',55,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(56,1,'P. Tân Sơn','phuong','p-tan-son',56,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(57,1,'P. Tân Phú','phuong','p-tan-phu',57,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(58,1,'P. Tây Thạnh','phuong','p-tay-thanh',58,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(59,1,'P. Hiệp Tân','phuong','p-hiep-tan',59,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(60,1,'P. Tân Quý','phuong','p-tan-quy',60,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(61,1,'P. Hiệp Bình','phuong','p-hiep-binh',61,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(62,1,'P. Thủ Đức','phuong','p-thu-duc',62,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(63,1,'P. Tam Bình','phuong','p-tam-binh',63,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(64,1,'P. Linh Trung','phuong','p-linh-trung',64,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(65,1,'P. Thủ Thiêm','phuong','p-thu-thiem',65,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(66,1,'P. Cát Lái','phuong','p-cat-lai',66,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(67,1,'P. An Khánh','phuong','p-an-khanh',67,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(68,1,'P. Thạnh Mỹ Lợi','phuong','p-thanh-my-loi',68,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(69,1,'P. Trường Thạnh','phuong','p-truong-thanh',69,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(70,1,'P. Phước Long','phuong','p-phuoc-long',70,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(71,1,'P. Tăng Nhơn Phú','phuong','p-tang-nhon-phu',71,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(72,1,'P. Long Trường','phuong','p-long-truong',72,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(73,1,'X. Vĩnh Lộc','xa','x-vinh-loc',73,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(74,1,'X. Tân Kiên','xa','x-tan-kien',74,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(75,1,'X. Bình Lợi','xa','x-binh-loi',75,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(76,1,'X. Lê Minh Xuân','xa','x-le-minh-xuan',76,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(77,1,'X. Phong Phú','xa','x-phong-phu',77,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(78,1,'X. Đa Phước','xa','x-da-phuoc',78,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(79,1,'X. Quy Đức','xa','x-quy-duc',79,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(80,1,'X. Bình Khánh','xa','x-binh-khanh',80,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(81,1,'X. An Thới Đông','xa','x-an-thoi-dong',81,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(82,1,'X. Tam Thôn Hiệp','xa','x-tam-thon-hiep',82,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(83,1,'X. Lý Nhơn','xa','x-ly-nhon',83,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(84,1,'X. Long Hòa','xa','x-long-hoa',84,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(85,1,'ĐK. Thạnh An','dac_khu','dk-thanh-an',85,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(86,1,'X. Tân An Hội','xa','x-tan-an-hoi',86,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(87,1,'X. Phước Vĩnh An','xa','x-phuoc-vinh-an',87,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(88,1,'X. Trung An','xa','x-trung-an',88,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(89,1,'X. Tân Thạnh Đông','xa','x-tan-thanh-dong',89,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(90,1,'X. Phú Hòa Đông','xa','x-phu-hoa-dong',90,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(91,1,'X. Hòa Phú','xa','x-hoa-phu',91,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(92,1,'X. Nhuận Đức','xa','x-nhuan-duc',92,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(93,1,'X. Xuân Thới Thượng','xa','x-xuan-thoi-thuong',93,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(94,1,'X. Tân Hiệp','xa','x-tan-hiep',94,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(95,1,'X. Đông Thạnh','xa','x-dong-thanh',95,1,'2026-03-29 15:06:38','2026-03-29 15:06:38'),(96,1,'X. Phước Kiển','xa','x-phuoc-kien',96,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(97,1,'X. Hiệp Phước','xa','x-hiep-phuoc',97,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(98,1,'P. Thủ Dầu Một','phuong','p-thu-dau-mot',100,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(99,1,'P. Phú Hòa','phuong','p-phu-hoa',101,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(100,1,'P. Chánh Nghĩa','phuong','p-chanh-nghia',102,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(101,1,'P. Hiệp Thành (BD)','phuong','p-hiep-thanh-bd',103,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(102,1,'P. Dĩ An','phuong','p-di-an',104,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(103,1,'P. Đông Hòa','phuong','p-dong-hoa',105,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(104,1,'P. Tân Đông Hiệp','phuong','p-tan-dong-hiep',106,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(105,1,'P. Thuận An','phuong','p-thuan-an',107,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(106,1,'P. Bình Hòa','phuong','p-binh-hoa',108,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(107,1,'P. An Phú (BD)','phuong','p-an-phu-bd',109,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(108,1,'P. Uyên Hưng','phuong','p-uyen-hung',110,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(109,1,'P. Tân Phước Khánh','phuong','p-tan-phuoc-khanh',111,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(110,1,'P. Thái Hòa','phuong','p-thai-hoa',112,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(111,1,'P. Mỹ Phước','phuong','p-my-phuoc',113,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(112,1,'P. Thới Hòa','phuong','p-thoi-hoa',114,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(113,1,'X. Lai Uyên','xa','x-lai-uyen',115,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(114,1,'X. Tân Hưng (BD)','xa','x-tan-hung-bd',116,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(115,1,'X. Long Nguyên','xa','x-long-nguyen',117,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(116,1,'X. Tân Định (BD)','xa','x-tan-dinh-bd',118,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(117,1,'X. Tân Mỹ','xa','x-tan-my',119,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(118,1,'X. Đất Cuốc','xa','x-dat-cuoc',120,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(119,1,'X. Minh Hòa','xa','x-minh-hoa',121,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(120,1,'X. Định Thành','xa','x-dinh-thanh',122,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(121,1,'X. Long Hòa (BD)','xa','x-long-hoa-bd',123,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(122,1,'X. An Bình (BD)','xa','x-an-binh-bd',124,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(123,1,'X. Tân Hiệp (BD)','xa','x-tan-hiep-bd',125,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(124,1,'X. Phước Sang','xa','x-phuoc-sang',126,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(125,1,'X. An Lập','xa','x-an-lap',127,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(126,1,'X. Thanh Tuyền','xa','x-thanh-tuyen',128,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(127,1,'X. Minh Tân','xa','x-minh-tan',129,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(128,1,'X. Phú An','xa','x-phu-an',130,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(129,1,'X. Vĩnh Hòa','xa','x-vinh-hoa',131,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(130,1,'X. An Long','xa','x-an-long',132,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(131,1,'X. An Linh','xa','x-an-linh',133,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(132,1,'X. Tân Lập (BD)','xa','x-tan-lap-bd',134,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(133,1,'X. Phước Hòa (BD)','xa','x-phuoc-hoa-bd',135,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(134,1,'P. Vũng Tàu','phuong','p-vung-tau',140,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(135,1,'P. Thắng Nhất','phuong','p-thang-nhat',141,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(136,1,'P. Rạch Dừa','phuong','p-rach-dua',142,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(137,1,'P. Nguyễn An Ninh','phuong','p-nguyen-an-ninh',143,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(138,1,'P. Long Toàn','phuong','p-long-toan',144,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(139,1,'P. Phước Hiệp','phuong','p-phuoc-hiep',145,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(140,1,'P. Kim Dinh','phuong','p-kim-dinh',146,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(141,1,'P. Phú Mỹ','phuong','p-phu-my',147,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(142,1,'P. Mỹ Xuân','phuong','p-my-xuan',148,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(143,1,'P. Tân Phước (BRVT)','phuong','p-tan-phuoc-brvt',149,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(144,1,'X. Long Sơn','xa','x-long-son',150,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(145,1,'X. Hòa Hiệp','xa','x-hoa-hiep',151,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(146,1,'X. Bình Châu','xa','x-binh-chau',152,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(147,1,'X. Châu Pha','xa','x-chau-pha',153,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(148,1,'X. Sông Xoài','xa','x-song-xoai',154,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(149,1,'X. Hắc Dịch','xa','x-hac-dich',155,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(150,1,'X. Ngãi Giao','xa','x-ngai-giao',156,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(151,1,'X. Suối Nghệ','xa','x-suoi-nghe',157,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(152,1,'X. Bình Ba','xa','x-binh-ba',158,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(153,1,'X. Láng Lớn','xa','x-lang-lon',159,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(154,1,'X. Quảng Thành','xa','x-quang-thanh',160,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(155,1,'X. Kim Long','xa','x-kim-long',161,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(156,1,'X. Phước Tỉnh','xa','x-phuoc-tinh',162,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(157,1,'X. Long Hải','xa','x-long-hai',163,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(158,1,'X. Phước Hải','xa','x-phuoc-hai',164,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(159,1,'X. Đất Đỏ','xa','x-dat-do',165,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(160,1,'X. Lộc An (BRVT)','xa','x-loc-an-brvt',166,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(161,1,'X. Phước Bửu','xa','x-phuoc-buu',167,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(162,1,'X. Bông Trang','xa','x-bong-trang',168,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(163,1,'X. Bưng Riềng','xa','x-bung-rieng',169,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(164,2,'P. Trấn Biên','phuong','p-tran-bien',1,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(165,2,'P. Tam Hiệp','phuong','p-tam-hiep',2,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(166,2,'P. Tân Phong (BH)','phuong','p-tan-phong-bh',3,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(167,2,'P. Bửu Hòa','phuong','p-buu-hoa',4,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(168,2,'P. Long Bình','phuong','p-long-binh',5,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(169,2,'P. Tam Phước','phuong','p-tam-phuoc',6,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(170,2,'P. Phước Tân','phuong','p-phuoc-tan',7,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(171,2,'P. An Hòa (BH)','phuong','p-an-hoa-bh',8,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(172,2,'P. Hiệp Hòa','phuong','p-hiep-hoa',9,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(173,2,'P. Xuân An','phuong','p-xuan-an',10,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(174,2,'P. Xuân Lập','phuong','p-xuan-lap',11,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(175,2,'P. Xuân Bình','phuong','p-xuan-binh',12,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(176,2,'P. Xuân Trung','phuong','p-xuan-trung',13,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(177,2,'X. Long Thành','xa','x-long-thanh',14,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(178,2,'X. An Phước','xa','x-an-phuoc',15,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(179,2,'X. Phước Thái','xa','x-phuoc-thai',16,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(180,2,'X. Tam An','xa','x-tam-an',17,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(181,2,'X. Phú Hội','xa','x-phu-hoi',18,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(182,2,'X. Phước Thiền','xa','x-phuoc-thien',19,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(183,2,'X. Long Tân','xa','x-long-tan',20,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(184,2,'X. Hiệp Phước (ĐN)','xa','x-hiep-phuoc-dn',21,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(185,2,'X. Trảng Bom','xa','x-trang-bom',22,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(186,2,'X. Bắc Sơn','xa','x-bac-son',23,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(187,2,'X. Hố Nai 3','xa','x-ho-nai-3',24,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(188,2,'X. Sông Thao','xa','x-song-thao',25,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(189,2,'X. Dầu Giây','xa','x-dau-giay',26,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(190,2,'X. Xuân Thiện','xa','x-xuan-thien',27,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(191,2,'X. Bàu Hàm 2','xa','x-bau-ham-2',28,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(192,2,'X. Vĩnh An','xa','x-vinh-an',29,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(193,2,'X. Thiện Tân','xa','x-thien-tan',30,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(194,2,'X. Phú Lý','xa','x-phu-ly',31,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(195,2,'X. Mã Đà','xa','x-ma-da',32,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(196,2,'X. Xuân Hưng','xa','x-xuan-hung',33,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(197,2,'X. Xuân Tâm','xa','x-xuan-tam',34,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(198,2,'X. Suối Cát','xa','x-suoi-cat',35,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(199,2,'X. Xuân Hòa (XL)','xa','x-xuan-hoa-xl',36,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(200,2,'X. Định Quán','xa','x-dinh-quan',37,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(201,2,'X. Phú Ngọc','xa','x-phu-ngoc',38,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(202,2,'X. Thanh Sơn','xa','x-thanh-son',39,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(203,2,'X. La Ngà','xa','x-la-nga',40,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(204,2,'X. Tân Phú (ĐN)','xa','x-tan-phu-dn',41,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(205,2,'X. Phú Sơn','xa','x-phu-son',42,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(206,2,'X. Đak Lua','xa','x-dak-lua',43,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(207,2,'X. Nam Cát Tiên','xa','x-nam-cat-tien',44,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(208,2,'X. Long Giao','xa','x-long-giao',45,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(209,2,'X. Xuân Quế','xa','x-xuan-que',46,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(210,2,'X. Sông Nhạn','xa','x-song-nhan',47,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(211,2,'X. Xuân Đông','xa','x-xuan-dong',48,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(212,2,'P. Tân Phú (BP)','phuong','p-tan-phu-bp',50,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(213,2,'P. Tân Đồng','phuong','p-tan-dong',51,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(214,2,'P. Tân Xuân','phuong','p-tan-xuan',52,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(215,2,'P. Tân Thiện','phuong','p-tan-thien',53,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(216,2,'P. Tiến Thành','phuong','p-tien-thanh',54,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(217,2,'X. Phước Bình','xa','x-phuoc-binh',55,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(218,2,'X. Long Giang','xa','x-long-giang',56,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(219,2,'X. Bình Tân (BP)','xa','x-binh-tan-bp',57,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(220,2,'X. An Khương','xa','x-an-khuong',58,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(221,2,'X. Thanh Phú (BP)','xa','x-thanh-phu-bp',59,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(222,2,'X. Thanh Lương','xa','x-thanh-luong',60,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(223,2,'X. Minh Lập','xa','x-minh-lap',61,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(224,2,'X. Nha Bích','xa','x-nha-bich',62,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(225,2,'X. Thành Tâm','xa','x-thanh-tam',63,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(226,2,'X. Đức Liễu','xa','x-duc-lieu',64,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(227,2,'X. Nghĩa Trung','xa','x-nghia-trung',65,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(228,2,'X. Đồng Nai (BĐ)','xa','x-dong-nai-bd',66,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(229,2,'X. Thống Nhất (BĐ)','xa','x-thong-nhat-bd',67,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(230,2,'X. Bù Gia Mập','xa','x-bu-gia-map',68,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(231,2,'X. Đăk Ơ','xa','x-dak-o',69,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(232,2,'X. Phú Nghĩa','xa','x-phu-nghia',70,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(233,2,'X. Đa Kia','xa','x-da-kia',71,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(234,2,'X. Thanh Hòa (BĐ)','xa','x-thanh-hoa-bd',72,1,'2026-03-29 15:06:39','2026-03-29 15:06:39'),(236,2,'Lộc Thạnh','xa','loc-thanh',0,1,'2026-03-29 16:20:50','2026-03-29 16:20:50'),(237,2,'Lộc Thành','xa','loc-thanh-2',0,1,'2026-03-29 16:21:03','2026-03-29 16:21:03');
/*!40000 ALTER TABLE `wards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'khodat'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-29  9:37:09
